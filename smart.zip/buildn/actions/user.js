const minutesInput = document.getElementById("minutes");
const secondsInput = document.getElementById("seconds");
const countdownDisplay = document.getElementById("countdown");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const resetButton = document.getElementById("reset");
const statusMessage = document.getElementById("status-message");
const analyzeButtonContainer = document.getElementById("analyze-button-container");
const progressBar = document.getElementById("progress");
const progressBarContainer = document.getElementById("progress-bar-container");
const statusBarContainer = document.getElementById("status-bar-container");

let countdownInterval;
let totalSeconds;

function updateCountdownDisplay() {
  const minutes = parseInt(minutesInput.value) || 0;
  const seconds = parseInt(secondsInput.value) || 0;
  totalSeconds = minutes * 60 + seconds;
  displayTime(totalSeconds);
}

function displayTime(seconds) {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  countdownDisplay.textContent = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

function showStatus(message, showSpinner = false, progress = 0) {
  statusMessage.textContent = message;
  statusBarContainer.style.display = showSpinner ? 'flex' : 'block';
  updateProgressBar(progress);
}

function showAnalyzeButton() {
  analyzeButtonContainer.style.display = "block";
}

function updateProgressBar(percentage) {
  progressBar.style.width = `${percentage}%`;
  if (percentage === 100) {
    // Change color to green when finished
    progressBar.style.backgroundColor = '#4CAF50'; // Green color
  }
}

function startCountdown() {
  if (totalSeconds > 0 && !countdownInterval) {
    showStatus("Recording started...", true, 0);
    countdownInterval = setInterval(() => {
      totalSeconds--;
      displayTime(totalSeconds);

      // Update progress for the countdown phase
      const countdownProgress = ((minutesInput.value * 60 + secondsInput.value - totalSeconds) / (minutesInput.value * 60 + secondsInput.value)) * 50;
      updateProgressBar(countdownProgress);

      if (totalSeconds <= 0) {
        clearInterval(countdownInterval);
        countdownInterval = null;
        handleRecordingEnd();
      }
    }, 1000);
  }
}

function stopCountdown() {
  if (countdownInterval) {
    clearInterval(countdownInterval);
    countdownInterval = null;
    handleRecordingEnd();
  }
}

function handleRecordingEnd() {
  showStatus("Recording stopped.", false, 50);
  setTimeout(() => {
    showStatus("Converting voice to text...", true, 60);
    setTimeout(() => {
      showStatus("Conversion complete.", false, 100);
      showAnalyzeButton();
      // Change the progress bar to green after completion
      updateProgressBar(100);
    }, 15000);
  }, 2000);
}

function resetCountdown() {
  clearInterval(countdownInterval);
  countdownInterval = null;
  analyzeButtonContainer.style.display = "none";
  statusMessage.textContent = "Ready";
  progressBar.style.width = "0";
  progressBar.style.backgroundColor = "#3b82f6"; // Reset to blue
  updateCountdownDisplay();
}

function redirectToAnalyzePage() {
  window.location.href = "templates/analyze_results.html";
}

minutesInput.addEventListener("input", updateCountdownDisplay);
secondsInput.addEventListener("input", updateCountdownDisplay);
startButton.addEventListener("click", startCountdown);
stopButton.addEventListener("click", stopCountdown);
resetButton.addEventListener("click", resetCountdown);

updateCountdownDisplay();