const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('nav');
let menuOpen = false;

menuToggle.addEventListener('click', () => {
  nav.classList.toggle('show');
  menuOpen = !menuOpen;
  menuToggle.textContent = menuOpen ? '✖' : '☰'; // Change between hamburger and close icon
});