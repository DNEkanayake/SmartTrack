 // Toggle between login and register forms
 const loginForm = document.getElementById("login");
 const registerForm = document.getElementById("register");

 document.querySelectorAll(".switch a").forEach((link) => {
   link.addEventListener("click", (e) => {
     e.preventDefault();
     loginForm.style.display =
       loginForm.style.display === "none" ? "block" : "none";
     registerForm.style.display =
       registerForm.style.display === "none" ? "block" : "none";
   });
 });

 // Handle Registration
 function handleRegister(event) {
   event.preventDefault();

   const username = document.getElementById("regusername").value;
   const email = document.getElementById("email").value;
   const password = document.getElementById("regpassword").value;
   const confirmPassword = document.getElementById("confirm-password").value;

   if (password !== confirmPassword) {
     alert("Passwords do not match!");
     return;
   }

   const users = JSON.parse(localStorage.getItem("users") || "[]");

   // Check if username already exists
   if (users.some((user) => user.username === username)) {
     alert("Username already exists. Please choose a different one.");
     return;
   }

   // Save user details
   users.push({ username, email, password });
   localStorage.setItem("users", JSON.stringify(users));
   alert("Registration successful! You can now log in.");
   document.querySelector(".switch a").click(); // Switch to login form
 }

 // Handle Login
 function handleLogin(event) {
   event.preventDefault();

   const username = document.getElementById("username").value;
   const password = document.getElementById("password").value;

   const users = JSON.parse(localStorage.getItem("users") || "[]");

   // Validate credentials
   const user = users.find(
     (user) => user.username === username && user.password === password
   );

   if (user) {
     localStorage.setItem("currentUser", username); // Mark session
     window.location.href = "user.html"; // Redirect to user page
   } else {
     alert("Invalid username or password.");
   }
 }