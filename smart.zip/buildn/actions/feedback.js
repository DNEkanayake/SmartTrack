const countdownElement = document.getElementById("countdown");
const minutesInput = document.getElementById("minutes");
const secondsInput = document.getElementById("seconds");
const presentationTitleInput = document.getElementById("presentation-title");
const startButton = document.getElementById("start");
const stopButton = document.getElementById("stop");
const resetButton = document.getElementById("reset");
const esp32ResponseBox = document.getElementById("esp32-response");

let timer;
let remainingTime = 0;
let isRunning = false;

function updateDisplay(time) {
  const minutes = Math.floor(time / 60);
  const seconds = time % 60;
  countdownElement.textContent = `${minutes}:${
    seconds < 10 ? "0" : ""
  }${seconds}`;
}

function setTimer() {
  const inputMinutes = parseInt(minutesInput.value, 10) || 0;
  const inputSeconds = parseInt(secondsInput.value, 10) || 0;
  remainingTime = inputMinutes * 60 + inputSeconds;
  updateDisplay(remainingTime);
}

async function sendTitleAndTime(title, time) {
  try {
    const response = await fetch("YOUR_LAMBDA_API_URL_HERE", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title: title,
        time: time,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to send data to Lambda.");
    }

    const data = await response.json();
    console.log("Data sent successfully:", data);

    if (data.response) {
      esp32ResponseBox.value += `ESP32: ${data.response}\n`;
    }
  } catch (error) {
    console.error("Error sending data:", error);
    esp32ResponseBox.value += `Error: ${error.message}\n`;
  }
}

function startTimer() {
  const presentationTitle = presentationTitleInput.value.trim();
  if (!presentationTitle) {
    alert("Please enter a presentation title before starting the timer.");
    return;
  }

  if (remainingTime === 0) {
    setTimer();
  }

  if (!isRunning) {
    // Send title and time to Lambda
    sendTitleAndTime(presentationTitle, remainingTime);

    timer = setInterval(() => {
      if (remainingTime > 0) {
        remainingTime--;
        updateDisplay(remainingTime);
      } else {
        clearInterval(timer);
        isRunning = false;
        alert("Time's up!");
      }
    }, 1000);
    isRunning = true;
  }
}

function stopTimer() {
  if (isRunning) {
    clearInterval(timer);
    isRunning = false;
  }
}

function resetTimer() {
  clearInterval(timer);
  setTimer();
  isRunning = false;
}

startButton.addEventListener("click", startTimer);
stopButton.addEventListener("click", stopTimer);
resetButton.addEventListener("click", resetTimer);

updateDisplay(remainingTime);
