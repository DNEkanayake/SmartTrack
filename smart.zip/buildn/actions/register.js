async function handleReg(event) {
  event.preventDefault(); // Prevent default form submission

  const pid = document.getElementById("productId").value;
  const username = document.getElementById("regusername").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("regpassword").value;

  const url =
    " https://anub7asoe6.execute-api.us-east-1.amazonaws.com/default/pyreg"; // Replace with your Lambda URL
  const data = { pid, username, email, password };

  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    const result = await response.json();

    if (response.status === 200) {
      // Redirect to the dashboard page (or any other page)
      window.location.href = "user.html"; // Replace with the URL of the page you want to redirect to
    } else {
      alert("Error: " + result.error);
    }
  } catch (error) {
    alert("Error: Unable to reach the server.");
  }
}
