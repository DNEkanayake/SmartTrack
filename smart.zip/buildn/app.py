from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from transformers import pipeline
from sentence_transformers import SentenceTransformer, util
import boto3
import re
from decimal import Decimal  # Import Decimal

app = Flask(__name__)
CORS(app)  # Enable CORS

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Update your region

def fetch_presentation_text(table, presentation_id):
    """Fetch the presentation text by ID from DynamoDB."""
    response = table.get_item(Key={'id': presentation_id})
    if 'Item' not in response:
        raise ValueError(f"Presentation with ID {presentation_id} not found.")
    return response['Item']['presentation_text']

def summarize_text(text):
    """Summarize the given text."""
    summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
    summary = summarizer(text, max_length=150, min_length=50, do_sample=False)
    return summary[0]['summary_text']

def analyze_sentiment(text):
    """Analyze sentiment of the given text."""
    sentiment_analyzer = pipeline("sentiment-analysis")
    max_input_length = 512
    chunks = [text[i:i+max_input_length] for i in range(0, len(text), max_input_length)]
    sentiments = [sentiment_analyzer(chunk)[0]['label'] for chunk in chunks]
    return "Positive" if "POSITIVE" in sentiments else "Negative"

def count_filler_words(text):
    """Count filler words in the text."""
    filler_words = ["um", "ah", "uh", "like", "you know"]
    filler_count = {word: len(re.findall(rf'\b{word}\b', text, re.IGNORECASE)) for word in filler_words}
    return sum(filler_count.values())

def calculate_topic_relevance(text, topic_sentence):
    """Calculate topic relevance score and level."""
    model = SentenceTransformer('all-MiniLM-L6-v2')
    text_embedding = model.encode(text, convert_to_tensor=True)
    topic_embedding = model.encode(topic_sentence, convert_to_tensor=True)
    similarity_score = util.cos_sim(text_embedding, topic_embedding).item() * 100

    if similarity_score > 80.0:
        relevance = "High Relevance"
    elif similarity_score > 50.0:
        relevance = "Moderate Relevance"
    else:
        relevance = "Low Relevance"

    return similarity_score, relevance

def update_analysis_results(table, presentation_id, filler_count, similarity_score, summary, sentiment):
    """Update the analysis results in DynamoDB."""
    # Convert similarity_score and filler_count to Decimal
    similarity_score = Decimal(str(similarity_score))
    filler_count = Decimal(str(filler_count))

    table.update_item(
        Key={'id': presentation_id},
        UpdateExpression="SET filler_words_count = :f, topic_relevance = :t, presentation_summery = :s, sentiment_of_the_presentation = :p",
        ExpressionAttributeValues={
            ':f': filler_count,
            ':t': similarity_score,
            ':s': summary,
            ':p': sentiment
        }
    )

def analyze_presentation(presentation_id, topic_sentence):
    """Main function to perform analysis on the presentation."""
    table = dynamodb.Table('Presentations')  # Replace with your table name

    # Fetch the presentation text
    text = fetch_presentation_text(table, presentation_id)

    # Perform analyses
    summary = summarize_text(text)
    sentiment = analyze_sentiment(text)
    filler_count = count_filler_words(text)
    similarity_score, relevance = calculate_topic_relevance(text, topic_sentence)

    # Update results in DynamoDB
    update_analysis_results(table, presentation_id, filler_count, similarity_score, summary, sentiment)

    return {
        "presentation_text": text,
        "summary": summary,
        "sentiment": sentiment,
        "filler_count": filler_count,
        "similarity_score": similarity_score,
        "relevance": relevance
    }

@app.route('/')
def home():
    """Render the HTML form."""
    return render_template('analyze_results.html')  # Ensure your HTML file is in the 'templates' folder

@app.route('/analyze', methods=['POST'])
def analyze():
    """Endpoint to analyze a presentation."""
    if request.is_json:
        # Handle JSON request (e.g., from API clients)
        data = request.json
    else:
        # Handle form submission (from HTML)
        data = request.form

    presentation_id = data.get('presentation_id')
    topic_sentence = data.get('topic')

    if not presentation_id or not topic_sentence:
        return jsonify({"error": "Both presentation_id and topic are required."}), 400

    try:
        results = analyze_presentation(presentation_id, topic_sentence)
        return jsonify({
            "message": "Analysis completed successfully.",
            "results": results
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
